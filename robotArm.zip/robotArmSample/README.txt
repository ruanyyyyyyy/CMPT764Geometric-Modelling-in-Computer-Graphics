This program inplements all requirements in the assignment. You can select side/top view in the drop-down menu
after the "Choose a view:". The hierarchical model is orinally without any rotation and in side view. After user inputs 
a pair of old and new positions and clicks "Fetch" button, the hierarchical model will start to work. After
it finishes moving the ball from old position to the new position, it will return to the state before the button 
is clicked.