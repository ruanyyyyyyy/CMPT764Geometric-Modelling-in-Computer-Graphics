face.png sourced from https://imgur.com/gallery/fUQdfkM
